def check_installation():
    print("the package is correctly installed!")
